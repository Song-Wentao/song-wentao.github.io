function loadComponent(targetId, file, callback) {
    fetch(`/Project/CatCafe/Website/components/${file}`)
        .then(response => {
            if (!response.ok) throw new Error(`Failed to load ${file}`);
            return response.text();
        })
        .then(html => {
            document.getElementById(targetId).innerHTML = html;
            if (callback) callback();
        })
        .catch(err => console.error(err));
}

function initNavbar() {
    const menuIcon = document.getElementById('menu-icon');
    const navLinks = document.querySelector('.nav-links');
    if (!menuIcon || !navLinks) return;

    menuIcon.addEventListener('click', () => {
        navLinks.classList.toggle('open');
        menuIcon.classList.toggle('open');
    });

    navLinks.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('open');
            menuIcon.classList.remove('open');
        });
    });
}

window.addEventListener('scroll', () => {
    const nav = document.querySelector('nav');
    if (!nav) return;
    nav.style.boxShadow = window.pageYOffset > 100
        ? '0 4px 20px rgba(0,0,0,0.15)'
        : '0 2px 10px rgba(0,0,0,0.1)';
});

document.addEventListener('DOMContentLoaded', () => {
    loadComponent('navbar', 'navbar.html', initNavbar);
});